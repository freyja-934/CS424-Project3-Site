library(testthat)
library(AotClient)

test_check("AotClient")
